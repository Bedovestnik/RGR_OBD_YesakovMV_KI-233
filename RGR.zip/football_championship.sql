-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Дек 20 2024 г., 15:38
-- Версия сервера: 10.4.32-MariaDB
-- Версия PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `football_championship`
--

-- --------------------------------------------------------

--
-- Структура таблицы `bet`
--

CREATE TABLE `bet` (
  `bet_id` bigint(20) UNSIGNED NOT NULL,
  `bet_size` int(20) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `match_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `bet`
--

INSERT INTO `bet` (`bet_id`, `bet_size`, `user_id`, `match_id`) VALUES
(0, 100, 1, 1),
(1, 1000, 1, 4),
(2, 200, 2, 2),
(3, 150, 3, 3),
(4, 250, 4, 4),
(5, 300, 5, 5),
(6, 100, 6, 6),
(7, 200, 7, 7),
(8, 150, 8, 8),
(9, 250, 9, 9);

-- --------------------------------------------------------

--
-- Структура таблицы `football_match`
--

CREATE TABLE `football_match` (
  `match_id` int(11) NOT NULL,
  `match_status` text NOT NULL,
  `organizer_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `football_match`
--

INSERT INTO `football_match` (`match_id`, `match_status`, `organizer_id`) VALUES
(1, 'in_progress', 8),
(2, 'cancelled', 2),
(3, 'completed', 3),
(4, 'in_progress', 9),
(5, 'cancelled', 1),
(6, 'completed', 4),
(7, 'in_progress', 7),
(8, 'cancelled', 5),
(9, 'completed', 2),
(10, 'in_progress', 6);

-- --------------------------------------------------------

--
-- Структура таблицы `organizer`
--

CREATE TABLE `organizer` (
  `organizer_id` bigint(20) UNSIGNED NOT NULL,
  `organizer_email` text NOT NULL,
  `organizer_password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `organizer`
--

INSERT INTO `organizer` (`organizer_id`, `organizer_email`, `organizer_password`) VALUES
(0, 'organizer2@example.com', 'password2'),
(1, 'organizer1@example.com', 'password1'),
(2, 'organizer@gmail.com', 'asdfgh'),
(3, 'organizer3@example.com', 'password3'),
(4, 'organizer4@example.com', 'password4'),
(5, 'organizer5@example.com', 'password5'),
(6, 'organizer6@example.com', 'password6'),
(7, 'organizer7@example.com', 'password7'),
(8, 'organizer8@example.com', 'password8'),
(9, 'organizer9@example.com', 'password9');

-- --------------------------------------------------------

--
-- Структура таблицы `review`
--

CREATE TABLE `review` (
  `review_id` bigint(20) UNSIGNED NOT NULL,
  `rating` int(20) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `match_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `review`
--

INSERT INTO `review` (`review_id`, `rating`, `user_id`, `match_id`) VALUES
(0, 4, 1, 1),
(1, 9, 1, 4),
(2, 5, 2, 2),
(3, 3, 3, 3),
(4, 4, 4, 4),
(5, 2, 5, 5),
(6, 5, 6, 6),
(7, 3, 7, 7),
(8, 4, 8, 8),
(9, 5, 9, 9);

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`user_id`, `email`, `password`) VALUES
(1, 'test@gmail.com', '$2y$10$R6l.gQpzBiSbt4uFjTHCeecfSh.u25Gxis2YFJ1HJfbkIxggbTezS'),
(2, 'zaproxy@example.com', '$2y$10$UGymRbs1HufCo.YsarXEPOOiH..77nowpDzLW..9mt3HNeQO8PEGW'),
(3, 'c:/Windows/system.ini', '$2y$10$6sW.NSuzCQBnxdFXfWxNIOjT1qvJbuUF2OB3QZ1BggLWqMrltkgsa'),
(4, '\'', '$2y$10$nnOAcM6q.hrOBbIjQbpj1uQlfFhFAmBoEZTyIXIWNgenWRwWuFyBC'),
(5, '\";print(chr(122).chr(97).chr(112).chr(95).chr(116).chr(111).chr(107).chr(101).chr(110));$var=\"', '$2y$10$c0YC5KgJSiKSvUJrXwLCrOYId65suDhJa84QvCERNEI13WpAMnpF.');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `bet`
--
ALTER TABLE `bet`
  ADD PRIMARY KEY (`bet_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `match_id` (`match_id`);

--
-- Индексы таблицы `football_match`
--
ALTER TABLE `football_match`
  ADD PRIMARY KEY (`match_id`),
  ADD KEY `organizer_id` (`organizer_id`);

--
-- Индексы таблицы `organizer`
--
ALTER TABLE `organizer`
  ADD PRIMARY KEY (`organizer_id`);

--
-- Индексы таблицы `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`review_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `match_id` (`match_id`);

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `football_match`
--
ALTER TABLE `football_match`
  MODIFY `match_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `football_match`
--
ALTER TABLE `football_match`
  ADD CONSTRAINT `football_match_ibfk_1` FOREIGN KEY (`organizer_id`) REFERENCES `organizer` (`organizer_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
