<?php
session_start();
session_unset(); // Очищаємо всі сесійні змінні
session_destroy(); // Знищуємо сесію
header('Location: index.php'); // Перенаправлення на головну сторінку
exit();
