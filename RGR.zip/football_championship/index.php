<?php
session_start();
require 'db_config.php'; // Підключення до бази даних

// Виконання SQL запиту для отримання даних з таблиці football_match
$query = "SELECT * FROM football_match";
$result = $pdo->query($query);

// Перевірка чи є результати
if ($result) {
    // Виведення таблиці з результатами
    echo "<h2>Список матчів</h2>";
    echo "<table class='blue-table'>
            <tr>
                <th>Match ID</th>
                <th>Status</th>
                <th>Organizer ID</th>
            </tr>";

    // Виведення кожного рядка з результатами запиту
    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>
                <td>" . $row['match_id'] . "</td>
                <td>" . $row['match_status'] . "</td>
                <td>" . $row['organizer_id'] . "</td>
              </tr>";
    }

    echo "</table>";
} else {
    echo "Не вдалося отримати дані з таблиці.";
}

// Додати новий матч
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_match'])) {
    $match_status = $_POST['match_status'];
    $organizer_id = $_POST['organizer_id'];

    // SQL запит для додавання нового матчу
    $insertQuery = "INSERT INTO football_match (match_status, organizer_id) VALUES (?, ?)";
    $stmt = $pdo->prepare($insertQuery);
    if ($stmt->execute([$match_status, $organizer_id])) {
        echo "Новий матч успішно додано!";
    } else {
        echo "Помилка при додаванні матчу.";
    }
}

// Видалення матчу
if (isset($_GET['delete'])) {
    $delete_id = $_GET['delete'];

    // SQL запит для видалення матчу
    $deleteQuery = "DELETE FROM football_match WHERE match_id = ?";
    $stmt = $pdo->prepare($deleteQuery);
    if ($stmt->execute([$delete_id])) {
        echo "Матч успішно видалено!";
        // Перезавантажуємо сторінку після видалення
        header("Location: index.php");
        exit;
    } else {
        echo "Помилка при видаленні матчу.";
    }
}
?>

<!-- Додавання кнопок для входу/реєстрації/виходу -->
<div style="position: absolute; top: 10px; right: 10px;">
    <?php if (isset($_SESSION['user_id'])): ?>
        <span>Вітаємо, <?php echo $_SESSION['email']; ?></span>
        <a href="logout.php">Вийти</a>
    <?php else: ?>
        <a href="login.php">Увійти</a> | <a href="register.php">Зареєструватися</a>
    <?php endif; ?>
</div>

<!-- Форма для додавання нового матчу -->
<h3>Додати новий матч</h3>
<form method="POST" action="">
    <label for="match_status">Статус матчу:</label>
    <input type="text" name="match_status" required><br><br>
    
    <label for="organizer_id">ID організатора:</label>
    <input type="number" name="organizer_id" required><br><br>
    
    <input type="submit" name="add_match" value="Додати матч">
</form>

<!-- Список матчів з кнопками для видалення -->
<h3>Матчі в базі даних</h3>
<table class="blue-table">
    <tr>
        <th>Match ID</th>
        <th>Status</th>
        <th>Organizer ID</th>
        <th>Дія</th>
    </tr>

<?php
// Виконання SQL запиту для отримання даних з таблиці football_match
$query = "SELECT * FROM football_match";
$result = $pdo->query($query);

// Виведення кожного матчевого рядка з кнопкою для видалення
if ($result) {
    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>
                <td>" . $row['match_id'] . "</td>
                <td>" . $row['match_status'] . "</td>
                <td>" . $row['organizer_id'] . "</td>
                <td><a href='?delete=" . $row['match_id'] . "' onclick='return confirm(\"Ви впевнені, що хочете видалити цей матч?\")'>Видалити</a></td>
              </tr>";
    }
}
?>
</table>

</body>
</html>

<style>
    /* Синя таблиця */
    .blue-table {
        width: 80%;
        margin: 20px auto;
        border-collapse: collapse;
        background-color: #e7f3ff;
    }

    .blue-table th, .blue-table td {
        padding: 12px;
        text-align: left;
        border: 1px solid #007bff;
    }

    .blue-table th {
        background-color: #007bff;
        color: white;
    }

    .blue-table tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    .blue-table tr:hover {
        background-color: #ddd;
    }

    /* Стилі для кнопок */
    .auth-buttons {
        position: absolute;
        top: 10px;
        right: 10px;
    }

    .auth-buttons a {
        margin: 0 10px;
        padding: 10px 20px;
        text-decoration: none;
        background-color: #007bff;
        color: white;
        border-radius: 5px;
    }

    .auth-buttons a:hover {
        background-color: #0056b3;
    }
</style>
