<?php
session_start();
require 'db_config.php';  // Підключення до бази даних

// Перевірка, чи користувач вже авторизований
if (isset($_SESSION['user_id'])) {
    header("Location: index.php"); // Перенаправлення на головну сторінку, якщо користувач вже авторизований
    exit();
}

// Обробка форми реєстрації
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $password_confirm = $_POST['password_confirm'];

    // Перевірка, чи паролі збігаються
    if ($password != $password_confirm) {
        echo "Паролі не збігаються!";
    } else {
        // Хешування пароля для безпеки
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Перевірка, чи існує користувач з таким email
        $stmt = $pdo->prepare("SELECT * FROM user WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->rowCount() > 0) {
            echo "Користувач з таким email вже існує!";
        } else {
            // Запис нової інформації в базу даних
            $stmt = $pdo->prepare("INSERT INTO user (email, password) VALUES (?, ?)");
            if ($stmt->execute([$email, $hashed_password])) {
                echo "Реєстрація успішна!";
                // Перенаправлення на сторінку входу або авторизації
                header("Location: login.php");
                exit();
            } else {
                echo "Помилка при реєстрації.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Реєстрація</title>
</head>
<body>
    <h2>Реєстрація</h2>
    <form method="POST" action="">
        <label for="email">Електронна пошта:</label>
        <input type="email" name="email" required><br><br>

        <label for="password">Пароль:</label>
        <input type="password" name="password" required><br><br>

        <label for="password_confirm">Підтвердження пароля:</label>
        <input type="password" name="password_confirm" required><br><br>

        <input type="submit" value="Зареєструватися">
    </form>
    <p>Вже маєте акаунт? <a href="login.php">Увійти</a></p>
</body>
</html>
