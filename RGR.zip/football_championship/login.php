<?php
session_start();
require_once 'db_config.php'; // Підключення до бази даних

// Перевірка, чи була надіслана форма
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Отримуємо введені дані
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Перевіряємо наявність користувача в базі даних за email
    $stmt = $pdo->prepare("SELECT * FROM user WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    // Якщо користувач знайдений і пароль правильний
    if ($user && password_verify($password, $user['password'])) {
        // Створюємо сесію для користувача
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['email'] = $user['email'];

        // Перенаправляємо на головну сторінку або на сторінку користувача
        header("Location: index.php"); 
        exit(); // Завершуємо виконання скрипту після редіректу
    } else {
        // Якщо email або пароль невірні
        echo "Невірний email або пароль!";
    }
}
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вхід</title>
</head>
<body>
    <h2>Вхід в систему</h2>
    <form action="login.php" method="POST">
        <label for="email">Email:</label>
        <input type="email" name="email" required><br><br>

        <label for="password">Пароль:</label>
        <input type="password" name="password" required><br><br>

        <button type="submit">Увійти</button>
    </form>
</body>
</html>
