<?php
include_once('../includes/config.php');

// Підключення CSS
echo '<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ваш сайт з базою даних</title>
    <link rel="stylesheet" href="../css/styles.css"> <!-- Замість ../css/styles.css вкажіть шлях до вашого CSS файлу -->
</head>';

function getTableData($table) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM $table");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function insertData($table, $data) {
    global $pdo;
    $columns = implode(", ", array_keys($data));
    $values = ":" . implode(", :", array_keys($data));
    $stmt = $pdo->prepare("INSERT INTO $table ($columns) VALUES ($values)");
    $stmt->execute($data);
}

function deleteData($table, $id) {
    global $pdo;
    $stmt = $pdo->prepare("DELETE FROM $table WHERE id = :id");
    $stmt->execute([':id' => $id]);
}

function updateData($table, $data, $id) {
    global $pdo;
    $set = "";
    foreach ($data as $key => $value) {
        $set .= "$key = :$key, ";
    }
    $set = rtrim($set, ", ");
    $stmt = $pdo->prepare("UPDATE $table SET $set WHERE id = :id");
    $data['id'] = $id;
    $stmt->execute($data);
}
?>
