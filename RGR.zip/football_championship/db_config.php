<?php
// Налаштування підключення до бази даних
$host = '127.0.0.1';  // Адреса хосту (локальний сервер)
$dbname = 'football_championship';  // Назва вашої бази даних
$username = 'root';  // Ваше ім'я користувача MySQL
$password = '';  // Ваш пароль для MySQL (якщо немає, залиште порожнім)

try {
    // Підключення до бази даних через PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // Якщо не вдалося підключитися, вивести повідомлення про помилку
    die("Connection failed: " . $e->getMessage());
}
?>
