<?php
session_start();  // Перше, що потрібно викликати

// Виведення ID користувача сесії, якщо він авторизований
echo "User ID: " . (isset($_SESSION['user_id']) ? $_SESSION['user_id'] : "No session");

// Якщо є сесія, ви можете додати додаткові повідомлення
if (isset($_SESSION['user_id'])) {
    echo "<br>Ви авторизовані, ваш email: " . $_SESSION['email'];
} else {
    echo "<br>Ви не авторизовані.";
}
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мій сайт</title>
</head>
<body>
    <!-- Ваш основний контент -->
    <h1>Ласкаво просимо на сайт!</h1>
    <p>Тут буде ваш контент.</p>
</body>
</html>
