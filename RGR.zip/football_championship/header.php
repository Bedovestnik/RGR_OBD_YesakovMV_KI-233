<?php
session_start();
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мій сайт</title>
    <style>
        /* Стилі для розміщення кнопок у правому верхньому куті */
        .auth-buttons {
            position: absolute;
            top: 20px;
            right: 20px;
        }
        .auth-buttons a {
            margin: 0 10px;
            padding: 10px 20px;
            text-decoration: none;
            background-color: #007bff;
            color: white;
            border-radius: 5px;
        }
        .auth-buttons a:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="auth-buttons">
    <?php
    if (!isset($_SESSION['user_id'])) {
        // Якщо користувач не авторизований, показуємо кнопки реєстрації та входу
        echo "<a href='register.php'>Реєстрація</a>";
        echo "<a href='login.php'>Вхід</a>";
    } else {
        // Якщо користувач авторизований, показуємо кнопку виходу
        echo "<a href='logout.php'>Вихід</a>";
    }
    ?>
</div>

<!-- Інший контент вашого сайту -->

</body>
</html>
