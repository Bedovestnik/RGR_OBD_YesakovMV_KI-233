<?php
include_once('../includes/config.php');
include_once('../functions/db.php');

// Виведення даних
$betData = getTableData('bet');

// Додавання нового запису
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add'])) {
    $data = [
        'bet_id' => $_POST['bet_id'],
        'bet_size' => $_POST['bet_size'],
        'user_id' => $_POST['user_id'],
        'match_id' => $_POST['match_id'],
    ];
    insertData('bet', $data);
    header('Location: bet.php');
}

// Видалення запису
if (isset($_GET['delete'])) {
    deleteData('bet', $_GET['delete']);
    header('Location: bet.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Bet Data</title>
</head>
<body>
    <h1>Bet Data</h1>
    <table>
        <tr>
            <th>Bet ID</th>
            <th>Bet Size</th>
            <th>User ID</th>
            <th>Match ID</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($betData as $row): ?>
            <tr>
                <td><?php echo $row['bet_id']; ?></td>
                <td><?php echo $row['bet_size']; ?></td>
                <td><?php echo $row['user_id']; ?></td>
                <td><?php echo $row['match_id']; ?></td>
                <td>
                    <a href="?delete=<?php echo $row['bet_id']; ?>">Delete</a>
                    <!-- Update logic could go here -->
                </td>
            </tr>
        <?php endforeach; ?>
    </table>

    <h2>Add New Bet</h2>
    <form method="POST">
        <input type="text" name="bet_id" placeholder="Bet ID" required><br>
        <input type="text" name="bet_size" placeholder="Bet Size" required><br>
        <input type="text" name="user_id" placeholder="User ID" required><br>
        <input type="text" name="match_id" placeholder="Match ID" required><br>
        <button type="submit" name="add">Add Bet</button>
    </form>
</body>
</html>
